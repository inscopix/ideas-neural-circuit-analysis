import configparser
import logging
import os
import pathlib
import platform
import typing as t
import warnings

import click

from ideas.utils import display

APP_NAME = "ideas-cli"
SAMPLE_CONFIG = """[auth]
# One of the supported environment names, use `ideas environments` to list
env = us

username = <YOUR IDEAS EMAIL>
password = <YOUR IDEAS PASSWORD>
"""

logger = logging.getLogger(__name__)


def get_default_config_path() -> pathlib.Path:
    return pathlib.Path(click.get_app_dir(APP_NAME)) / "config.ini"


def get_credentials_cache_path() -> pathlib.Path:
    return pathlib.Path(click.get_app_dir(APP_NAME)) / ".cache"


def read_cached_token(
    username: str, user_pool_id: str
) -> t.Tuple[t.Optional[str], t.Optional[str]]:
    try:
        with open(get_credentials_cache_path(), "r") as f:
            (
                stored_user_pool_id,
                stored_username,
                access_token,
                refresh_token,
            ) = f.read().split("|")

        if username != stored_username or user_pool_id != stored_user_pool_id:
            # Prevent using token stored for another account or environment
            return (None, None)

        return (access_token, refresh_token)
    except (FileNotFoundError, ValueError):
        # File is malformed or doesn't exist yet; will be regenerated on exit
        # Can pass this to a Cognito client and it will initialize itself for us
        return (None, None)


def write_cached_token(
    username: str,
    user_pool_id: str,
    access_token: t.Optional[str],
    refresh_token: t.Optional[str],
) -> None:
    """
    Write the access and refresh tokens to a cache file, taking care to not expose it to anyone but
    the current user.

    """
    # If the tokens aren't populated, abort early and clear the cached token. This is expected if
    # the auth flow failed.
    if access_token is None or refresh_token is None:
        clear_cached_token()
        return

    # Make sure the parent exists with restrictive permissions before creating
    # cache file.
    path = get_credentials_cache_path()
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)

    fd = os.open(
        path=path,
        flags=(
            os.O_WRONLY  # access mode: write only
            | os.O_CREAT  # create if not exists
            | os.O_TRUNC  # truncate the file to zero
        ),
        mode=0o600,
    )
    with open(fd, "w") as f:
        f.write("|".join([user_pool_id, username, access_token, refresh_token]))


def clear_cached_token() -> None:
    path = get_credentials_cache_path()

    try:
        os.remove(path)
    except FileNotFoundError:
        pass


def check_permissions(config_file: pathlib.Path) -> None:
    """
    We create the configuration file with specific permissions (i.e., only the owner can read) to
    prevent leaking of credentials, but it's possible the user created the file themselves or is
    supplying another configuration file path, so it's helpful to yell at them in that case.
    """

    def _check_permissions_windows(config_file: pathlib.Path) -> None:
        """
        Permissions on windows work differently
        Here we check that a single access entry exists for the file,
        and the entry is for the current user and grants full access
        Access is set when the config file is created by the CLI (see edit func)
        """
        import getpass

        import ntsecuritycon as con
        import win32security

        sd = win32security.GetFileSecurity(
            str(config_file), win32security.DACL_SECURITY_INFORMATION
        )
        dacl = sd.GetSecurityDescriptorDacl()  # instead of dacl = win32security.ACL()
        ace_count = dacl.GetAceCount()

        permissions_okay = False
        if ace_count == 1:
            _, access, usersid = dacl.GetAce(0)
            user, _, _ = win32security.LookupAccountSid("", usersid)
            user_name = getpass.getuser()
            if user == user_name and access == con.FILE_ALL_ACCESS:
                permissions_okay = True

        if not permissions_okay:
            warnings.warn(
                f"Permission on config file {config_file} are too permissive! "
                "It is recommended that your config file is not accessible by others."
            )

    if platform.system() == "Windows":
        import pywintypes

        try:
            _check_permissions_windows(config_file)
        except pywintypes.error as error:
            # Check error message for pywin32
            msg = error.args[2]
            # File doesn't exist so nothing to complain about
            if msg == "The system cannot find the file specified.":
                return
            raise error
        return

    # st_mode returns file type and permissions, so only consider the permissions
    try:
        current_permissions = config_file.stat().st_mode & 0o777
    except FileNotFoundError:
        # File doesn't exist so nothing to complain about
        return

    if current_permissions != 0o600:
        warnings.warn(
            f"Permissions {oct(current_permissions)} on config file {config_file} are too permissive! "
            "It is recommended that your config file is not accessible by others."
        )


def read_from_config_file(config_file: pathlib.Path) -> dict:
    """
    Read parameters from the configuration file, under the [auth] block by default, but optionally
    respecting the `IDEAS_CLI_PROFILE` environment variable to select another block.
    """
    config = configparser.ConfigParser()
    check_permissions(config_file)
    config.read(config_file)

    config_profile = os.environ.get("IDEAS_CLI_PROFILE")
    if config_profile is not None:
        profile_overridden = True
    else:
        config_profile = "auth"
        profile_overridden = False

    try:
        options = dict(config[config_profile])
    except KeyError:
        if profile_overridden:
            # Only log a warning if the user is trying to override the profile name; else, they
            # may not even have a config file nor want one.
            display.show_error(
                f"Unable to find specified profile '{config_profile}' in {config_file}, please "
                "check IDEAS_CLI_PROFILE value."
            )
        options = {}

    return options


def configure_cli(ctx, param, config_file: pathlib.Path) -> None:
    """
    Take the configured parameters and apply them to the click context's default mapping. This
    allows the user to still overwrite them with individual command-line arguments.
    """
    ctx.default_map = read_from_config_file(config_file)


def edit() -> None:
    """
    Edits the configuration file for the CLI, populating an editor with the template if it doesn't
    already exist.
    """

    def _make_file_access_for_user_only_windows(config_file):
        """
        Remove all access entries for config file, and add single access entry for current user.
        Meant to mimic 0o600 settings on Unix systems, but different since
        Windows permissions are more complicated.
        This still doesn't make access to the file limited only to the current user,
        since access can be inherited from parent folders.
        However since this folder is in the user's directory, only the user and admins
        should have access by default anyways.

        Windows permissions are generally evaluated in this order:

        * If a user matches explicit deny access, they're denied permission.
        * If a user matches explicit allow access, they're granted permission.
        * If a user matches inherited deny access, they're denied permission.
        * If a user matches inherited allow access, they're granted permission.
        * If there are no matches for a user, they're denied permission by default.

        Based on this example code: https://timgolden.me.uk/python/win32_how_do_i/add-security-to-a-file.html
        """
        import getpass

        import ntsecuritycon as con
        import win32security

        sd = win32security.GetFileSecurity(
            str(config_file), win32security.DACL_SECURITY_INFORMATION
        )
        dacl = sd.GetSecurityDescriptorDacl()  # instead of dacl = win32security.ACL()
        ace_count = dacl.GetAceCount()

        for _ in range(0, ace_count):
            dacl.DeleteAce(0)

        user_name = getpass.getuser()
        userx, _, _ = win32security.LookupAccountName("", user_name)
        dacl.AddAccessAllowedAce(win32security.ACL_REVISION, con.FILE_ALL_ACCESS, userx)
        sd.SetSecurityDescriptorDacl(1, dacl, 0)  # may not be necessary
        win32security.SetFileSecurity(
            str(config_file), win32security.DACL_SECURITY_INFORMATION, sd
        )

    config_file: pathlib.Path = get_default_config_path()

    if config_file.exists():
        # Already exists, so open an editor with the existing file
        configuration = click.edit(filename=str(config_file))
    else:
        # Make parent directory (if it doesn't already exist) and open an editor with the template
        # pre-populated, and restrict access to the owner only
        config_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)

        # Give the owner r/w permissions but nobody else should be able to read the secrets
        # contained within this file

        configuration = click.edit(SAMPLE_CONFIG, extension=".ini")

        if configuration is not None:
            config_file.write_text(configuration)
            config_file.touch(mode=0o600, exist_ok=True)

            if platform.system() == "Windows":
                _make_file_access_for_user_only_windows(config_file)

            display.show_success(
                f"Configuration file written successfully to {config_file}"
            )
        else:
            # User didn't save in the editor, or something went wrong while saving
            display.abort(
                "Unable to save configuration file, please try again.",
                log="Failed to save configuration file",
            )
