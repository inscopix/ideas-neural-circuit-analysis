from typing import TypeAlias

"""Type representing an IDEAS input file, as a string file path"""
IdeasFile: TypeAlias = str
